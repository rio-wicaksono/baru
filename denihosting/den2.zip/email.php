<?php
$jsonString = file_get_contents("deni/data.json");
$resultData = json_decode($jsonString, true);

$emailku = $resultData['email'];
$namares = $resultData['namares'];
$ukuran = $resultData['ukuran'];
$judul = $resultData['judul'];
$sender = "From: $namares <result@deni.com>";
